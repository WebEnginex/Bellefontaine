/// <reference types="cypress" />

declare global {
  namespace Cypress {
    interface Chainable {
      // Ajoutez vos commandes personnalisées ici si nécessaire
    }
  }
}
