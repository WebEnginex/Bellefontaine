describe('Profil utilisateur', () => {
  beforeEach(() => {
    // Se connecter avant chaque test
    cy.visit('/auth');
    cy.get('input[type="email"]').type('test@example.com');
    cy.get('input[type="password"]').type('Password123');
    cy.contains('button', 'Se connecter').click();
  });

  it('affiche les informations du profil', () => {
    cy.visit('/profil');
    
    cy.get('[data-testid="profile-info"]').within(() => {
      cy.contains('Prénom').should('be.visible');
      cy.contains('Nom').should('be.visible');
      cy.contains('Email').should('be.visible');
    });
  });

  it('permet de modifier les informations personnelles', () => {
    cy.visit('/profil');
    
    // Cliquer sur modifier
    cy.contains('button', 'Modifier').click();

    // Modifier les champs
    cy.get('input[name="firstName"]').clear().type('Nouveau Prénom');
    cy.get('input[name="lastName"]').clear().type('Nouveau Nom');

    // Sauvegarder
    cy.contains('button', 'Sauvegarder').click();

    // Vérifier la confirmation
    cy.contains('Profil mis à jour').should('be.visible');

    // Vérifier que les changements sont affichés
    cy.contains('Nouveau Prénom').should('be.visible');
    cy.contains('Nouveau Nom').should('be.visible');
  });

  it('permet de changer le mot de passe', () => {
    cy.visit('/profil');
    
    // Accéder au changement de mot de passe
    cy.contains('button', 'Changer le mot de passe').click();

    // Remplir le formulaire
    cy.get('input[name="currentPassword"]').type('Password123');
    cy.get('input[name="newPassword"]').type('NewPassword123');
    cy.get('input[name="confirmPassword"]').type('NewPassword123');

    // Soumettre
    cy.contains('button', 'Mettre à jour').click();

    // Vérifier la confirmation
    cy.contains('Mot de passe mis à jour').should('be.visible');
  });

  it('valide les règles du nouveau mot de passe', () => {
    cy.visit('/profil');
    
    cy.contains('button', 'Changer le mot de passe').click();

    // Essayer un mot de passe trop court
    cy.get('input[name="currentPassword"]').type('Password123');
    cy.get('input[name="newPassword"]').type('short');
    cy.get('input[name="confirmPassword"]').type('short');

    cy.contains('button', 'Mettre à jour').click();

    // Vérifier le message d'erreur
    cy.contains('Le mot de passe doit contenir au moins 6 caractères').should('be.visible');
  });

  it('vérifie que les mots de passe correspondent', () => {
    cy.visit('/profil');
    
    cy.contains('button', 'Changer le mot de passe').click();

    cy.get('input[name="currentPassword"]').type('Password123');
    cy.get('input[name="newPassword"]').type('NewPassword123');
    cy.get('input[name="confirmPassword"]').type('DifferentPassword123');

    cy.contains('button', 'Mettre à jour').click();

    cy.contains('Les mots de passe ne correspondent pas').should('be.visible');
  });
});
