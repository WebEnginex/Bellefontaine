describe('Réservations', () => {
  beforeEach(() => {
    // Se connecter avant chaque test
    cy.visit('/auth');
    cy.get('input[type="email"]').type('test@example.com');
    cy.get('input[type="password"]').type('Password123');
    cy.contains('button', 'Se connecter').click();
  });

  it('affiche la page de réservation', () => {
    cy.visit('/reserver');
    cy.contains('Réserver une session').should('be.visible');
  });

  it('permet de créer une réservation', () => {
    cy.visit('/reserver');
    
    // Sélectionner une date
    cy.get('[data-testid="date-picker"]').click();
    cy.get('.rdp-day').not('.rdp-day_disabled').first().click();

    // Sélectionner un créneau horaire
    cy.get('[data-testid="time-slot"]').first().click();

    // Confirmer la réservation
    cy.contains('button', 'Réserver').click();

    // Vérifier la confirmation
    cy.contains('Réservation confirmée').should('be.visible');
  });

  it('empêche la réservation de créneaux passés', () => {
    cy.visit('/reserver');
    
    // Vérifier que les dates passées sont désactivées
    cy.get('.rdp-day_disabled').should('exist');
  });

  it('permet d\'annuler une réservation', () => {
    cy.visit('/mes-reservations');
    
    // Trouver et annuler la première réservation
    cy.get('[data-testid="reservation-item"]').first().within(() => {
      cy.contains('button', 'Annuler').click();
    });

    // Confirmer l'annulation
    cy.contains('button', 'Confirmer').click();

    // Vérifier la confirmation
    cy.contains('Réservation annulée').should('be.visible');
  });

  it('affiche l\'historique des réservations', () => {
    cy.visit('/mes-reservations');
    
    // Vérifier que la liste des réservations est visible
    cy.get('[data-testid="reservation-list"]').should('exist');
    cy.get('[data-testid="reservation-item"]').should('have.length.at.least', 1);
  });
});
