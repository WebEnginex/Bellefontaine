describe('Authentification', () => {
  beforeEach(() => {
    cy.visit('/auth');
  });

  describe('Connexion', () => {
    it('permet de se connecter avec des identifiants valides', () => {
      cy.get('input[type="email"]').type('test@example.com');
      cy.get('input[type="password"]').type('Password123');
      cy.contains('button', 'Se connecter').click();

      // Vérifier la redirection
      cy.url().should('eq', Cypress.config().baseUrl + '/');
    });

    it('affiche une erreur avec des identifiants invalides', () => {
      cy.get('input[type="email"]').type('test@example.com');
      cy.get('input[type="password"]').type('wrongpassword');
      cy.contains('button', 'Se connecter').click();

      cy.contains('Identifiants invalides').should('be.visible');
    });

    it('permet d\'accéder au formulaire de mot de passe oublié', () => {
      cy.contains('Mot de passe oublié').click();
      cy.contains('Réinitialisation du mot de passe').should('be.visible');
    });
  });

  describe('Inscription', () => {
    beforeEach(() => {
      cy.contains('button', 'Inscription').click();
    });

    it('permet de créer un nouveau compte', () => {
      cy.get('input[placeholder*="Prénom"]').type('John');
      cy.get('input[placeholder*="Nom"]').type('Doe');
      cy.get('input[type="email"]').type('john.doe@example.com');
      cy.get('input[type="password"]').type('Password123');
      cy.contains('button', 'S\'inscrire').click();

      cy.contains('Vérifiez votre boîte mail').should('be.visible');
    });

    it('valide les champs obligatoires', () => {
      cy.contains('button', 'S\'inscrire').click();
      cy.contains('Veuillez remplir tous les champs').should('be.visible');
    });

    it('valide le format de l\'email', () => {
      cy.get('input[placeholder*="Prénom"]').type('John');
      cy.get('input[placeholder*="Nom"]').type('Doe');
      cy.get('input[type="email"]').type('invalid-email');
      cy.get('input[type="password"]').type('Password123');
      cy.contains('button', 'S\'inscrire').click();

      cy.contains('Veuillez entrer une adresse email valide').should('be.visible');
    });

    it('valide les règles du mot de passe', () => {
      cy.get('input[placeholder*="Prénom"]').type('John');
      cy.get('input[placeholder*="Nom"]').type('Doe');
      cy.get('input[type="email"]').type('john.doe@example.com');
      cy.get('input[type="password"]').type('short');
      cy.contains('button', 'S\'inscrire').click();

      cy.contains('Le mot de passe doit contenir').should('be.visible');
    });
  });

  describe('Réinitialisation du mot de passe', () => {
    beforeEach(() => {
      cy.contains('Mot de passe oublié').click();
    });

    it('permet de demander un lien de réinitialisation', () => {
      cy.get('input[type="email"]').type('test@example.com');
      cy.contains('button', 'Envoyer le lien').click();

      cy.contains('Email envoyé').should('be.visible');
    });

    it('valide le format de l\'email', () => {
      cy.get('input[type="email"]').type('invalid-email');
      cy.contains('button', 'Envoyer le lien').click();

      cy.contains('Veuillez entrer une adresse email valide').should('be.visible');
    });

    it('permet de revenir à la page de connexion', () => {
      cy.contains('button', 'Retour').click();
      cy.contains('Connexion').should('be.visible');
    });
  });
});
